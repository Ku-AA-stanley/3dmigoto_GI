Genshin v4.6 Remove Transparency Filter

Note that this is INCOMPATIBLE with TexFx. If you want to make use of TexFx, do not use this mod (TexFx comes with remove transparency filter by default)

To install, put the folder from Mods inside your 3dmigoto GIMI Mods folder, and the files from ShaderFixes inside your 3dmigoto ShaderFixes folder (must not be nested for ShaderFixes! top level only)

No need to remove previous files when updating, though you can if you want - it won't make a difference either way. If you get prompted, say yes to override.

You may have to restart the game for the mod to take effect - sometimes F10 is not enough.

Previous versions (v3.0-v3.3, v3.4-3.5, v3.6-3.7, v3.8, v4.0, v4.1, v4.2, v4.4) are archived on gamebanana.

If you want to support me, please consider leaving a tip at https://ko-fi.com/silentnightsound. Thank you!

- SilentNightSound